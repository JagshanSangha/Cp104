"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-10-24"
-------------------------------------------------------
"""
# Imports
from functions import mow_lawn
# Constants

# user input
width = int(input("Width (m): "))
length = int(input("Length (m): "))
speed = int(input("Speed (m^2/minute): "))

time = mow_lawn(width, length, speed)

# print new line
print()

# print output
print(f"Mowing the lawn takes {time:.0f} minutes")
