"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-10-24"
-------------------------------------------------------
"""
# Imports
from functions import date_extract
# Constants

# user input
date = int(input("Enter a date in the format MMDDYYYY: "))

year, month, day = date_extract(date)

# print new line
print()

# print output
print(f"The reformatted date: {year:04d}/{month:02d}/{day:02d}")
