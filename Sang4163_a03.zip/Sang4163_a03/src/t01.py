"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-10-24"
-------------------------------------------------------
"""
# Imports
from functions import feet_to_acres
# Constants
feet = float(input("Square footage: "))
acres = feet_to_acres(feet)

# formatting
two = "{:,.2f}".format(feet)

# prints new line
print()

# prints the output
print(f"{acres:.2f} acres is equivalent to {two} square feet")
