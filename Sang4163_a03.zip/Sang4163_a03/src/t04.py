"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-10-24"
-------------------------------------------------------
"""
# Imports
from fractions import Fraction
from functions import multiply_fractions
# Constants

# Userinput
num1 = int(input("Numerator 1: "))
den1 = int(input("Denominator 1: "))
num2 = int(input("Numerator 2: "))
den2 = int(input("Denominator 2: "))

numerator, denominator, product = multiply_fractions(num1, den1, num2, den2)
fraction = Fraction(numerator, denominator)

# Print new line
print()

# Print output
print(f"Result: {fraction} = {product:.3f}")
