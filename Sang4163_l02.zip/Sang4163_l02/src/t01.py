"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-09-23"
-------------------------------------------------------
"""
# Imports

# Constants
FREEZING = 32


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """



# input
Temp_celsius = int(input("Temperature (C) : "))

# Seperate input from output
print()

# Calculations
Temp_fahrenheit = (Temp_celsius * 9 / 5) + FREEZING

# Output
print(f"Temperature (F): {Temp_fahrenheit}")
