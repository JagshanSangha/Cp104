"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-09-23"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


# Input
Num_flyers = int(input("Number of flyers: "))
Num_volunteer = int(input("Number of volunteers: "))

# To separate the input from output
print()

# calculations
Per_volunteer = Num_flyers // Num_volunteer
Left_over = Num_flyers % Num_volunteer

# Output
print(f"Flyers per volunteer: {Per_volunteer}")
print(f"Flyers left over: {Left_over}")
