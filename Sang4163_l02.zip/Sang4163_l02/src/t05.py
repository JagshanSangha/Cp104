"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-09-23"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


# inputs
Hours_pay = float(input('Hourly rate of pay: $'))
Hours_worked = float(input('Hours worked in the week: $'))

# Calculations
Total_pay = Hours_pay * Hours_worked

# move to next line
print()

# output
print(f"Total pay for the week: ${Total_pay}")
