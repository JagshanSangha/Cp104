"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-09-23"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


# Constants
MONTHS_A_YEAR = 12

# input
principle = int(input('Mortgage principal ($): '))
total_years = int(input('Number of years: '))
yearly_rate = float(input('Yearly interest rate (%): '))

# Calculate the total months and monthly rate
months = total_years * MONTHS_A_YEAR
rate = yearly_rate / MONTHS_A_YEAR / 100

# Monthly payment
monthly_amount = principle * rate * (rate + 1)**months
monthly_amount /= (rate + 1)**months - 1

# Create a new line
print()

# Monthly payment total
print('The monthly payments are: $', monthly_amount)
