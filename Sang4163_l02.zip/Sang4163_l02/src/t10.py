"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-09-23"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


# input
Food_charge = float(input("Food Charge: $"))
Sales_tax = float(input("Sales Tax in (%): "))
Tip_percent = float(input("Tip in (%): "))

# create new line
print()

# Caculate cost of meal
print("Cost of meal:")

# variables
Subtotal = Food_charge
Tax = (Food_charge * Sales_tax) / 100
Tip = (Food_charge * Tip_percent) / 100
Total = Subtotal + Tax + Tip

# output
print(f"Subtotal: $ {Subtotal}")
print(f"Tax: $ {Tax}")
print(f"Tip: $ {Tip}")
print()
print("-----------------")

# Total price
print(Total)
