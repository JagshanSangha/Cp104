"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-11-26"
-------------------------------------------------------
"""
# Imports
from functions import customer_first
# Constants
fh = open("customers.txt", "r", encoding="utf-8")
print("Find customer with earliest sign-in:")
result = customer_first(fh)
print(result)
fh.close()
