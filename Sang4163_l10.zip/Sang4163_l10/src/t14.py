"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-11-26"
-------------------------------------------------------
"""
# Imports
from functions import file_copy_n
# Constants

print("Copying 'words.txt' to 'new_words.txt'")
n = int(input("Enter number of lines to copy: "))
filename = "words.txt"
new_file = "new_words.txt"
fh_1 = open(filename, "r", encoding="utf-8")
fh_2 = open(filename, "a", encoding="utf-8")
file_copy_n(fh_1, fh_2, n)
fh_1.close
fh_2.close
