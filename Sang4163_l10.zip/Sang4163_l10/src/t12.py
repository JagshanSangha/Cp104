"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-11-26"
-------------------------------------------------------
"""
# Imports
from functions import find_shortest
# Constants
fh = open('words.txt', 'r', encoding='utf-8')
result = find_shortest(fh)
print(result)
fh.close()
