"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-11-26"
-------------------------------------------------------
"""
# Imports
from functions import customer_record
# Constants
n = int(input('Find record n \nEnter a record number: '))
filename = 'customers.txt'
fh = open(filename, 'r', encoding='utf-8')
result = customer_record(fh, n)
print(result)
fh.close()
