"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-11-26"
-------------------------------------------------------
"""
# Imports
from functions import append_increment

# Opening files
filename = "numbers.txt"
fh = open(filename, "r+", encoding="utf-8")
print("file 'numbers.txt' open for reading and writing")

# Function calls
num = append_increment(fh)

# Closing files + outputs
fh.close()
print(f"{num} is appended")
