"""
-------------------------------------------------------
Midterm A Task 1 Function Definitions
-------------------------------------------------------
Author: Jagshan Sangha
ID:     169024163
Email:  sang4163@mylaurier.ca
__updated__ = "2022-11-02"
-------------------------------------------------------
"""
# Constants

# your code here


def total_coins(nickels, dimes, quarters, loonies):
    """
    -------------------------------------------------------
    Determines total amount of money in coins in cents.
        1 nickel = 5 cents
        1 dime = 10 cents
        1 quarter = 25 cents
        1 loonie = 100 cents
    Use: total = total_coins(nickels, dimes, quarters, loonies)
    -------------------------------------------------------
    Parameters:
        nickels - number of nickels (int >= 0)
        dimes - number of dimes (int >= 0)
        quarters - number of quarters (int >= 0)
        loonies - number of loonies (int >= 0)
    Returns‌​‌​​​​‌​​‌‌​​​‌‌​‌​‌​‌​​​‌‌:
        total - total value of coins in cents (int)
    -------------------------------------------------------
    """

    # your code here
    NICK = 0.05
    DIME = 0.10
    QUAR = 0.25
    LOON = 1.00

    total = (NICK * nickels) + (DIME * dimes) + \
        (QUAR * quarters) + (LOON * loonies)

    return total
