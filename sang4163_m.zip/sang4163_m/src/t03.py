"""
-------------------------------------------------------
Midterm A Task 3 Testing
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = "2022-10-29"
-------------------------------------------------------
"""
# Imports
from t03_functions import video_game_purchase

cost = video_game_purchase()
print(f"Cost: ${cost:.2f}")
