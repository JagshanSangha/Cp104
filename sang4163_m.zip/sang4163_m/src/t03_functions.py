"""
-------------------------------------------------------
Midterm A Task 3 Function Definitions
-------------------------------------------------------
Author: Jagshan Sangha
ID:     169024163
Email:  sang4163@mylaurier.ca
__updated__ = "2022-11-02"
-------------------------------------------------------
"""
# Constants

# your code here


def video_game_purchase():
    """
    -------------------------------------------------------
    Determines the cost of a video game. The cost is made up of:
        base cost: $45.00
        cost per DLC (DownLoadable Content): $5.00
        VIP discount 10% only if:
            more than 1 DLCs purchased
            and purchaser is a VIP
    Use: cost = video_game_purchase()
    -------------------------------------------------------
    Returns‌​‌​​​​‌​​‌‌​​​‌‌​‌​‌​‌​​​‌‌:
        cost - cost of a video game based upon the base game,
            the number of DLCs purchased, and VIP discount
            if applicable (float)
    -------------------------------------------------------
    """

    # your code here
    BASECOST = 45.00
    COST_PER_DLC = 5.00
    VIP_DISCOUNT = 0.10

    Dlc_bought = int(input("How many Dlc's have you purchased: "))

    if Dlc_bought > 1:
        VIP_Member = input("Are you a VIP Member (Y for yes/ N for No): ")
        if(VIP_Member == 'Y'):
            cost = (BASECOST + (COST_PER_DLC * Dlc_bought)) - \
                ((BASECOST + (COST_PER_DLC * Dlc_bought)) * VIP_DISCOUNT)
        else:
            cost = (BASECOST + (COST_PER_DLC * Dlc_bought))
    elif Dlc_bought == 1:
        cost = (BASECOST + (COST_PER_DLC * Dlc_bought))
    else:
        cost = (BASECOST)
    return cost
