"""
-------------------------------------------------------
Midterm A Task 4 Testing
-------------------------------------------------------
Author: Jagshan Sangha
ID:     169024163
Email:  sang4163@mylaurier.ca
__updated__ = "2022-11-02"
-------------------------------------------------------
"""
# Imports
from t04_functions import categorize
# your testing code here

# must ask user to input test values
value = int(input("Enter Integer to Categorize: "))

category = categorize(value)

print(category)
