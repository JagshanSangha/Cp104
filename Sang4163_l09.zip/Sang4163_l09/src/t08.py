"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-11-19"
-------------------------------------------------------
"""
# Imports
from functions import digit_count
# Constants

# print the output
count = digit_count('I know 1 thing - there are 2 kinds of people.')
print(count)
