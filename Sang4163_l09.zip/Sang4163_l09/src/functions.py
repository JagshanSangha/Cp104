"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-11-19"
-------------------------------------------------------
"""
# Imports

# Constants


def url_categorize(url):
    """
    -------------------------------------------------------
    Returns whether a url represents a business, a non-profit, or another
    type of organization.
    Use: url_type = url_categorize(url)
    -------------------------------------------------------
    Parameters:
        url - the web address of the organization (str)
    Returns:
        url_type - the organization type (str)
            'business' if url ends with 'com'
            'non-profit' if url ends with 'org'
            'other' if url ends with something else
    ------------------------------------------------------
    """

    # if else statement
    if url.endswith("com"):
        url_type = "business"
    elif url.endswith("org"):
        url_type = "non-profit"
    else:
        url_type = "other"

    return (url_type)


def parse_code(product_code):
    """
    -------------------------------------------------------
    Parses a given product code. A product code has three parts:
        The first three letters describe the product category
        The next four digits are the product ID
        The remaining characters describe the product's qualifiers
    Use: pc, pi, pq = parse_code(product_code)
    -------------------------------------------------------
    Parameters:
        product_code - a valid product code (str)
    Returns:
        pc - the category part of product_code (str)
        pi - the id part of product_code (str)
        pq - the qualifier part of product_code (str)
    -------------------------------------------------------
    """
    # product code string
    pc = product_code[0:3]
    pi = product_code[3:7]
    pq = product_code[7::]

    return (pc, pi, pq)

# task 8


def digit_count(s):
    """
    -------------------------------------------------------
    Counts the number of digits in a string.
    Use: count = digit_count(s)
    -------------------------------------------------------
    Parameters:
        s - a string (str)
    Returns:
        count - the number of digits in s (int)
    -------------------------------------------------------
    """
    # give count a value
    count = 0

    # for loop
    for i in s:
        if i.isdigit():
            count = count + 1

    return count


def dsmvwl(string):
    """
    -------------------------------------------------------
    Disemvowels a string. Returns a copy of s with all the vowels
    removed. Y is not treated as a vowel. Preserves case.
    Use: out = dsmvwl(sstring)
    -------------------------------------------------------
    Parameters:
        string - a string (str)
    Returns:
        out - string with its vowels removed (str)
    -------------------------------------------------------
    """
    # string
    out = ""

    # for loop
    for i in string:
        if i not in "aeiouAEIOU":
            out += i

    return(out)


def calculate(expr):
    """
    -----------------------------------------------------------------
    Treats expr as a math expression and evaluates it.
    expr must have the following format:
        operand1 operator operand2
    operators are: +, -, *, /, %
    operands are one-digit integer numbers
    Return None if second operand is zero for division.
    Use: result = calculate(expr)
    -----------------------------------------------------------------
    Parameters:
        expr - an arithmetic expression to be calculated (str)
    Returns:
        result - The result of arithmetic expression (float)
    -----------------------------------------------------------------
    """
    # list
    num1 = expr[0]
    num2 = expr[4]
    oper = expr[2]

    num1 = int(num1)
    num2 = int(num2)

    # if else statement
    if oper == "-":
        result = (num1) - (num2)
    elif oper == "+":
        result = (num1) + (num2)
    elif oper == "*":
        result = (num1) * (num2)
    elif oper == "/":
        if num2 == 0:
            result = None
        else:
            result = (num1) / (num2)
    elif oper == "%":
        if num2 == 0:
            result = None
        else:
            result = num1 % num2
    else:
        result = None

    return result
