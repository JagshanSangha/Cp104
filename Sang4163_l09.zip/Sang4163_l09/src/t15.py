"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-11-19"
-------------------------------------------------------
"""
# Imports
from functions import calculate
# Constants

# print output
result = calculate('5 + 4')
print(result)
