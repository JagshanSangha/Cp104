"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-11-19"
-------------------------------------------------------
"""
# Imports
from functions import parse_code
# Constants

# print output with formatting
pc, pi, pq = parse_code('ATV3482S14')
print(f"('{pc}', '{pi}','{pq}')")
