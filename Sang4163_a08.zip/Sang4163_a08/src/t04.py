"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-11-27"
-------------------------------------------------------
"""
# Imports
from functions import is_valid_isbn
# Constants
output = is_valid_isbn('978-3-16-148410-0')
print(output)
