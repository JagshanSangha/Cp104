"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-11-27"
-------------------------------------------------------
"""
# Imports

# Constants


def add_spaces(string):
    """
    -------------------------------------------------------
    Create a new string with added space between words. Words start
    with upper-case characters.
    Use: new_string = add_spaces(string)
    -------------------------------------------------------
    Parameters:
        string - string that represents a sentence in which all the
            words are run together (no spaces), but the first character
            of each word is uppercase. string has at least one
            character (str)
    Returns:
        new_string - new string in which the words are separated
            by spaces and only the first word starts with
            an uppercase character (str)
    -------------------------------------------------------
    """
    # string
    new_string = ''
    upstring = string.upper()

    # forloop
    for i in range(len(string)):
        if string[i] in upstring and i != 0:
            new_string += ' '
            new_string += string[i].lower()
        else:
            new_string += string[i]
    # return statement
    return(new_string)


def pluralize(string):
    """
    -------------------------------------------------------
    Pluralizes a string according to the rules:
        - if string ends with 's', 'sh', or 'ch', add 'es'
        - if string ends with 'y' but not 'ay' or 'oy', replace
            the 'y' with 'ies'
        - otherwise add 's'
    Use: plural = pluralize(string)
    -------------------------------------------------------
    Parameters:
        string - a string (str)
    Returns:
        plural - a plural version of string (str)
    -------------------------------------------------------
    """
    # string
    plural = ''

    # if else statement
    if string[len(string) - 1] == 'h' and string[len(string) - 2] == 's' or string[len(string) - 1] == 'h' and string[len(string) - 2] == 'c':
        plural += string[0:len(string) - 2] + 'es'
    elif string[len(string) - 1] == 's':
        plural += string[0:len(string) - 1] + 'es'
    elif string[len(string) - 1] == 'y' and string[len(string) - 2] == 'o' or string[len(string) - 1] == 'y' and string[len(string) - 2] == 'a':
        plural += string[0: len(string)] + 's'
    elif string[len(string) - 1] == 'y':
        plural += string[0:len(string) - 1] + 'ies'
    else:
        plural += string[0: len(string)] + 's'

    # return statement
    return(plural)


def common_ending(string1, string2):
    """
    -------------------------------------------------------
    Returns the longest common ending of two strings.
    Use: common = common_ending(string1, string2)
    -------------------------------------------------------
    Parameters:
        string1 - first string for ending comparison (str)
        string2 - second string for ending comparison (str)
    Returns:
        common - the longest common ending of string1 and string2 (str)
    -------------------------------------------------------
    """

    # if else statement
    if len(string1) - len(string2) > 0:
        string2 = (len(string1) - len(string2)) * ' ' + string2
    elif len(string2) - len(string1) > 0:
        string1 = (len(string2) - len(string1)) * ' ' + string1

    # string
    common = ''

    # for loop
    for i in range(len(string1)):
        if string1[i:] == string2[i:]:
            common += string1[i]

    # return statement
    return(common)


def is_valid_isbn(isbn):
    """
    -------------------------------------------------------
    Determines if an ISBN string is valid. An ISBN string is valid if:
        - it consists of only digits and dashes ('-')
        - it contains 5 groups of digits separated by dashes
        - its first group of digits is either '978' or '979'
        - its final group of digits is a single digit
        - its entire length is 17 characters
    Use: valid = is_valid_isbn(isbn)
    -------------------------------------------------------
    Parameters:
        isbn - a string (str)
    Returns:
        valid - True if isbn is valid, False otherwise (boolean)
    -------------------------------------------------------
    """
    # string
    new_isbn = ''

    # for loop
    for i in range(len(isbn)):
        if isbn[i] == '-':
            new_isbn += ''
        else:
            new_isbn += isbn[i]

    # boolean
    valid = False

    # if else statements
    if len(isbn) == 17:
        if isbn[0:3] == '978' or '979':
            if isbn.count('-') == 4:
                if '--' not in isbn:
                    if new_isbn.isdigit():
                        if isbn[16:].isdigit():
                            valid = True

    # return statement
    return(valid)


def is_word_chain(word_list):
    """
    -------------------------------------------------------
    Determines if a list of strings is a word chain. A word chain
    is a list of words in which the last character of a word in
    the list is the same as the first character of the next word
    in the list.
    Use: word_chain = is_word_chain(word_list)
    -------------------------------------------------------
    Parameters:
        word_list - a of strings (list of str, len > 1)
    Returns:
        word_chain - True if word_list is a word chain,
            False otherwise (boolean)
    -------------------------------------------------------
    """
    # boolean
    word_chain = False

    # for loop
    for i in range(len(word_list) - 1):
        if word_list[i][-1] == word_list[i + 1][0]:
            word_chain = True

    # return statement
    return(word_chain)
