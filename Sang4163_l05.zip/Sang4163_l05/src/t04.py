"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-10-22"
-------------------------------------------------------
"""
# Imports
from functions import closest
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use:
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """

    target = float(input("What is the target?"))
    v1 = float(input("What is v1?"))
    v2 = float(input("What is v2?"))

    result = closest(target, v1, v2)

    print(f"\nClosest value to {target} is {closest(target, v1, v2)}")
