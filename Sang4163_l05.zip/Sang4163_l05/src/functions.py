"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-10-22"
-------------------------------------------------------
"""
# Imports
from math import fabs
# Constants


def magic_date(day, month, year):
    """
    -------------------------------------------------------
    Determines if a date is magic. A date is magic if the day
    times the month equals the year.
    Use: magic = magic_date(day, month, year)
    -------------------------------------------------------
    Parameters:
        day - numeric day (int > 0)
        month - numeric month (int > 0)
        year - numeric two-digit year (int > 0)
    Returns:
        magic - True if date is magic, False otherwise (boolean)
    -------------------------------------------------------
    """

    if day * month == year:
        magic = True
    else:
        magic = False

    return magic


def gym_cost(cost, friends):
    """
    -------------------------------------------------------
    Calculates total cost of a gym membership. A member gets a
    discount according to the number of friends they sign up.
        0 friends: 0% discount
        1 friend: 5% discount
        2 friends: 10% discount
        3 or more friends: 15% discount
    Use: final_cost = gym_cost(cost, friends)
    -------------------------------------------------------
    Parameters:
        cost - a gym membership base cost (float > 0)
        friends - number of friends signed up (int >= 0)
    Returns:
        final_cost - cost of membership after discount (float)
    ------------------------------------------------------
    """
    FIVE_DISCOUNT = 0.05
    TEN_DISCOUNT = 0.10
    FIFTEEN_DISCOUNT = 0.15

    if friends < 1:
        final_cost = cost
    elif friends < 2:
        final_cost = cost - (cost * FIVE_DISCOUNT)
    elif friends < 3:
        final_cost = cost - (cost * TEN_DISCOUNT)
    else:
        final_cost = cost - (cost * FIFTEEN_DISCOUNT)
    return final_cost


def closest(target, v1, v2):
    """
    -------------------------------------------------------
    Determines closest value of two values to a target value.
    Use: result = closest(target, v1, v2)
    -------------------------------------------------------
    Parameters:
        target - the target value (float)
        v1 - first comparison value (float)
        v2 - second comparison value (float)
    Returns:
        result - one of v1 or v2 that is closest to target,
          v1 is the value chosen if v1 and v2 are an equal
          distance from target (float)
    -------------------------------------------------------
    """

    v2Diff = fabs(target - v2)
    v1Diff = fabs(target - v1)

    if v1Diff > v2Diff:
        result = v2

    else:
        result = v1

    return result


def wind_speed(speed):
    """
    -------------------------------------------------------
    description
    Use: category = wind_speed(speed)
    -------------------------------------------------------
    Parameters:
        speed - wind speed in km/hr (int >= 0)
    Returns:
        category - description of wind speed (str)
    ------------------------------------------------------
    """

    if speed > 117:
        category = "Hurricane"
    elif speed >= 89:
        category = "Whole Gale"
    elif speed >= 62:
        category = "Gale Winds"
    elif speed >= 39:
        category = "Strong Wind"
    elif speed > 0:
        category = "Breeze"
    else:
        category = "Unknown"
    return category


def fast_food():
    """
    -------------------------------------------------------
    Food order function.
    Asks user for their order and if they want a combo, and if
    necessary, what is the side order for the combo:
    Prices:
        Burger: $6.00
        Wings: $8.00
        Fries combo: add $1.50
        Salad combo: add $2.00
    Use: price = fast_food()
    -------------------------------------------------------
    Returns:
        price - the price of one meal (float)
    -------------------------------------------------------
    """
    BURGER = 6

    WINGS = 8

    FRIES = 1.50

    SALAD = 2

    cost = 0

    Order = input("Order: B - Burger  or W - Wings: ")

    if Order == "B":

        cost += BURGER

    elif Order == "W":

        cost += WINGS

    combo = input("Make it a combo? (Y/N): ")

    if combo == "Y":

        side = input("Add F - Fries or S - Salad: ")

        if side == "F":

            cost += FRIES

        elif side == "S":

            cost += SALAD

    return cost
