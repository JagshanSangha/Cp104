"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-10-02"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use:
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


# input
Fav_food = input("Enter your favourite food: ")
Fav_show = input("Enter your favourite Tv show: ")

# line break
print()

# Output
print(f"I like to eat {Fav_food} while watching {Fav_show}")
