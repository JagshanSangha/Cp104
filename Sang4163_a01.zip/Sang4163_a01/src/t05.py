"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-10-02"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use:
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


# input
Principal_amount = float(input("Principal: "))
Interest_rate = float(input("Interest (decimal): "))
Num_year = int(input("Number of years: "))
Num_compound = int(input("Number of times interest compounded per year: "))

# calculations
exponent = Num_compound * Num_year
fraction = Interest_rate / Num_compound
Compound_interest = Principal_amount * (1 + fraction) ** exponent

# line break
print()

# output
print(f"Balance: $ {Compound_interest}")
