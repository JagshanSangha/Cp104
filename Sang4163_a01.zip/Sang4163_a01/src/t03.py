"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-10-02"
-------------------------------------------------------
"""
# Imports


def func():
    """
    -------------------------------------------------------
    description
    Use:
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


# Constants
CONVERT_METRES = 0.0254

# input
Length_inch = int(input("Length in inches: "))

# calculation
Length_metres = Length_inch * CONVERT_METRES

# line break
print()

# output
print(f"Length in m: {Length_metres}")
