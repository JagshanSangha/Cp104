"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-10-02"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use:
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


# input
pizza_cost = float(input("Cost of 1 pizza slice: $"))
pizza_num = int(input("Number of pizza slices: "))

# calculations
total_cost = pizza_cost * pizza_num

# line break
print()

# output
print(f"Total cost of {pizza_num} pizza slices: $ {total_cost:.2f}")
