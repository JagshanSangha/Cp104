"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-10-10"
-------------------------------------------------------
"""
# Imports
from functions import tax
# Constants
ANNUAL_TAX = 18.50


def func():
    """
    -------------------------------------------------------
    description
    Use:
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


# Userinput
total_sales = int(input("Enter the total sales: $"))

# line break
print()

# dash variable
dash = '-'

# output
print("Projected Tax Report")
print(f'{dash:->25s}')
print(f"Total sales:  $ {total_sales:.2f}")
print(f"Annual tax:  % {ANNUAL_TAX:.2f}")
print(f"{dash:->25s}")
tax_total = tax * total_sales
print(f"Tax:           $ {tax_total:.2f}")
