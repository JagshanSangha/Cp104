"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-10-10"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use:
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


# input
two_digitnum = int(input("Enter a positive digit number: "))

# line break
print()

# calculation
num_1 = two_digitnum // 10
num_2 = two_digitnum % 10
digit_product = num_1 * num_2

# output
print(f"The product of the digits of {two_digitnum} is {digit_product}")
