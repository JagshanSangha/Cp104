"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-10-10"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use:
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


# user input
date = int(input("Enter a date in the format DDMMYY: "))

# line break
print()

# calculations
new_num = date % 1000000
num1 = new_num % 10000
num2 = new_num // 10000
num3 = date // 1000000

# output
print(f'The reformatted date: {num1}/{num2}/{num3}')
