"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-10-10"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use:
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


# input
Piece_cake = int(input("Number of pieces of cake: "))
Num_people = int(input("Number of party-goers: "))

# line break
print()

# calculations
Total_pieces = Piece_cake // Num_people
Pieces_left = Piece_cake % Num_people

# output
print(f'Each party-goer receives {Total_pieces} pieces of cake')
print(f"Pieces of cake that won't be distributed: {Pieces_left}")
