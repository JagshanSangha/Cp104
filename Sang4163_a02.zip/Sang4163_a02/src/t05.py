"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-10-10"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use:
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


# UserInput
Flength = float(input("Foundation length (m): "))
Fwidth = float(input("Foundation width (m): "))
Fheight = float(input("Foundation height (m): "))
Wheight = float(input("Wall height (m): "))
Cost_concrete = int(input("Cost of concrete ($/m^3): "))
Cost_bricks = int(input("Cost of bricks ($/m^2): "))

# line break
print()

# calculations
foundation_concrete = Flength * Fwidth * Fheight
total_concretecost = Cost_concrete * foundation_concrete
bricks_needed = (Fwidth * Wheight * 2) + (Flength * Wheight * 2)
total_brickcost = Cost_bricks * bricks_needed
total_cost = total_brickcost + total_concretecost

# output
print(f"Concrete needed for foundation (m^3): {foundation_concrete:.2f}")
print(f"Cost of concrete: ${total_concretecost:.2f}")
print(f"Bricks needed for walls (m^2): {bricks_needed:.2f}")
print(f"Cost of bricks: {total_brickcost:.2f}")
print(f"Total cost: ${total_cost:.2f}")
