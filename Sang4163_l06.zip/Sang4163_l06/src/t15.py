"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-10-29"
-------------------------------------------------------
"""
# Imports
from functions import statistics
# Constants

statistics(5)
