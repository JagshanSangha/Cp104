"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-10-29"
-------------------------------------------------------
"""
# Imports
from functions import sum_all
# Constants

sum_all(5, 10, 1)
