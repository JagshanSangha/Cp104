"""
-------------------------------------------------------
Exam Task 7 Function Definitions
Fall 2022
-------------------------------------------------------
Author: Jagshan Sangha
ID:     169024163
Email:  sang4163@mylaurier.ca
__updated__ = "2022-12-20"
-------------------------------------------------------
"""


def file_split(f_in, f_digits, f_no_digits):
    """
    -------------------------------------------------------
    Copies the contents of f_in to f_digits and f_no_digits depending
    on the contents of f_in:
        Lines containing digits are copied to f_digits.
        Lines without digits are copied to f_no_digits.
        Empty lines are ignored.
    Use: file_split(f_in, f_digits, f_no_digits)
    -------------------------------------------------------
    Parameters:
        f_in - source file (file handle - already open for reading)
        f_digits - file to contain lines with digits from f_in (file handle
            - already open for writing)
        f_no_digits - file to contain non-empty lines without digits from f_n
            (file handle - already open for writing)
    Returns‌​‌​​​​‌​​‌‌​​​‌‌​‌​‌​‌​​​‌‌:
        None
    -------------------------------------------------------
    """

    # Your code here

    # read the first line
    line = f_in.readline()

    # for loop for the file
    for line in f_in:

        # if else statement
        if any(c.isdigit() for c in line) is True:
            f_digits.write(line)
        else:
            f_no_digits.write(line)
    # return statement
    return
