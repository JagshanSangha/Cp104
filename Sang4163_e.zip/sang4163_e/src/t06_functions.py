"""
-------------------------------------------------------
Exam Task 6 Function Definitions
Fall 2022
-------------------------------------------------------
Author: Jagshan Sangha
ID:     169024163
Email:  sang4163@mylaurier.ca
__updated__ = "2022-12-20"
-------------------------------------------------------
"""


def rotate_list(values, n):
    """
    -------------------------------------------------------
    Rotates the elements in values n places:
        A positive n rotates elements from the front to the rear of values.
        A negative n rotates elements from the rear to the front of values.
    Use: rotate_list(values, n)
    -------------------------------------------------------
    Parameters:
        values - list of elements to rotate (list of *)
        n - number of places to rotate values (int)
    Returns‌​‌​​​​‌​​‌‌​​​‌‌​‌​‌​‌​​​‌‌:
        None
    -------------------------------------------------------
    """

    # Your code here

    # if the length of the list is equal to 0 then it will return nothing
    if len(values) == 0 or n == 0:
        return None
    # if length of the place > 0 then add that you pop 0 onto values
    if n > 0:
        for i in range(n):
            values.append(values.pop(0))
    # the else statement adds value to the other side
    else:
        for i in range(-n):
            values.insert(0, values.pop(0 - 1))
