"""
-------------------------------------------------------
Exam Task 2 Function Definitions
Fall 2022
-------------------------------------------------------
Author: Jagshan Sangha
ID:     169024163
Email:  sang4163@mylaurier.ca
__updated__ = "2022-12-20"
-------------------------------------------------------
"""
# Constants

# Your constants here


def temperatures():
    """
    -------------------------------------------------------
    Asks the user for daily high temperatures (in Celsius) from the keyboard.
    The function stops asking for temperatures when the user enters -500.
    The function returns:
        the total number of hot days (temperatures 28 or higher)
        the total number of pleasant days (temperatures 16 - 27)
        the total number of cold days (temperatures 15 or lower)
        the average temperature for all days (rounted down)
    Do all inputs and calculations in integer.
    Use: cold_days, pleasant_days, hot_days, avg_temp = temperatures()
    -------------------------------------------------------
    Returns‌​‌​​​​‌​​‌‌​​​‌‌​‌​‌​‌​​​‌‌:
        cold_days - number of cold days (int)
        pleasant_days - number of pleasant days (int)
        hot_days - number of hot days (int)
        avg_temp - average temperature of all days (int)
    -------------------------------------------------------
    """

    # Your code here

    # userinput for temperature
    temp_rature = int(input("Daily Temperatures (-500 to stop): "))

    # assign values to all variables
    hot = 0
    pleasant = 0
    cold = 0

    # add a count and total variable
    total = 0
    count = 0

    # while loop with a if else statement inside
    while temp_rature != -500:
        if temp_rature >= 28:
            hot += 1
        elif temp_rature <= 27 and temp_rature >= 16:
            pleasant += 1
        else:
            cold += 1
        count += 1
        total += temp_rature
        temp_rature = int(input("Daily Temperatures (-500 to stop): "))

    # average value calculations
    average = total / count

    # return statement
    return hot, pleasant, cold, average
