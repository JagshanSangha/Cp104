"""
-------------------------------------------------------
Exam Task 1 Function Definitions
Fall 2022
-------------------------------------------------------
Author: Jagshan Sangha
ID:     169024163
Email:  sang4163@mylaurier.ca
__updated__ = "2022-12-20"
-------------------------------------------------------
"""


def max_diff(values):
    """
    -------------------------------------------------------
    Returns largest absolute difference between adjacent
    values in a list. Returns 0 if values has fewer than two elements.
    Use: md = max_diff(values)
    -------------------------------------------------------
    Parameters:
        values - a list of values (list of int)
    Returns‌​‌​​​​‌​​‌‌​​​‌‌​‌​‌​‌​​​‌‌:
        md - the largest absolute difference between adjacent numbers in values (int)
    -------------------------------------------------------
    """

    # Your code here

    # assign a value to difference
    difference = 0

    # for loop
    for i in range(len(values) - 1):
        diff = abs(values[i] - values[i + 1])
        if diff >= difference:
            difference = diff

    # return statement
    return difference
