"""
-------------------------------------------------------
Exam Task 3 Function Definitions
Fall 2022
-------------------------------------------------------
Author: Jagshan Sangha
ID:     169024163
Email:  sang4163@mylaurier.ca
    __updated__ = "2022-12-20"
-------------------------------------------------------
"""


def alternate_case(string):
    """
    -------------------------------------------------------
    Converts letters in a string to alternate case. Letters
    at an even index are converted to (or left as) upper-case,
    Letters at an odd index are converted to (or left as)
    lower-case. Non-letters are ignored.
    Use: alternating = alternate_case(string)
    -------------------------------------------------------
    Parameters:
        width - maximum width in characters of triangle (int >= 1)
    Returns‌​‌​​​​‌​​‌‌​​​‌‌​‌​‌​‌​​​‌‌:
        alternating - the resulting string (str)
    -------------------------------------------------------
    """

    # Your code here
    alternating = ''
    for i in range(len(string)):
        if i % 2 == 0:
            letter = string[i].upper()
            alternating += letter
        if i % 2 != 0:
            letter2 = string[i].lower()
            alternating += letter2
    return alternating