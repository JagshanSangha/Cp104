"""
-------------------------------------------------------
Exam Task 5 Function Definitions
Fall 2022
-------------------------------------------------------
Author: Jagshan Sangha
ID:     169024163
Email:  sang4163@mylaurier.ca
__updated__ = "2022-12-20"
-------------------------------------------------------
"""


def sparse_matrix(fh_in):
    """
    -------------------------------------------------------
    Creates a sparse matrix 2D list.
    Use: matrix = sparse_matrix(fh_in)
    -------------------------------------------------------
    Parameters:
        fh_in - the matrix file to process (file handle - already open for reading)
    Returns‌​‌​​​​‌​​‌‌​​​‌‌​‌​‌​‌​​​‌‌:
        matrix - a 2D list of the form:
            [ [row, col, value], [row, col, value], ... ] (2D list of int)
    -------------------------------------------------------
    """

    # Your code here
    # 2dlist
    matrix = []
    row = 0

    # for loop
    for line in fh_in:
        # gets rid of unnecessary spaces and separates list by commas
        values = line.strip().split(',')
        # assign value to column
        column = 0

        # nested for loop
        for value in values:
            # if statement value can not equal 0
            if value != "0":
                # adds the row, column, and value to the matrix
                matrix.append([row, column, value])
            # adds column into column
            column += 1
        # adds row into row
        row += 1

    # return statement
    return matrix
