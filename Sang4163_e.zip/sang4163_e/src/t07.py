"""
-------------------------------------------------------
Testing for Task 7: file_split
-------------------------------------------------------
Author: Jagshan Sangha
ID:     169024163
Email:  sang4163@mylaurier.ca
__updated__ = "2022-12-20"
-------------------------------------------------------
"""
# Imports
from t07_functions import file_split
# Your code here

# file names
filename = "source.txt"
result1 = "withdigits.txt"
result2 = "withoutdigits.txt"

# open all three files and reading them
f_in = open(filename, "r", encoding="utf-8")
f_digits = open(result1, "w", encoding="utf-8")
f_no_digits = open(result2, "w", encoding="utf-8")

file_split(f_in, f_digits, f_no_digits)

# closing all three files
f_in.close()
f_digits.close()
f_no_digits.close()
