"""
-------------------------------------------------------
Exam Task 4 Function Definitions
Fall 2022
-------------------------------------------------------
Author: Jagshan Sangha
ID:     169024163
Email:  sang4163@mylaurier.ca
__updated__ = "2022-12-20"
-------------------------------------------------------
"""


def wide_triangle(width):
    """
    -------------------------------------------------------
    Prints a triangle in which each succeeding line is 3 characters
    longer than the previous line.
    Use: wide_triangle(width)
    -------------------------------------------------------
    Parameters:
        width - maximum width in characters of triangle (int >= 1)
    Returns‌​‌​​​​‌​​‌‌​​​‌‌​‌​‌​‌​​​‌‌:
        None
    -------------------------------------------------------
    """

    # Your code here

    # first for loop to print the top half of triangle
    for i in range(width - 6, width + 1, 3):
        print("#" * i)
    # second for loop to print the bottom half of triangle
    for i in range(width - 3, width - 9, -3):
        print("#" * i)
    # return statement
    return
