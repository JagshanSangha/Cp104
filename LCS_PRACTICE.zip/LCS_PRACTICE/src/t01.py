"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-12-20"
-------------------------------------------------------
"""
# Imports
from functions import flight_cost
# Constants
output = flight_cost(6.5, 12, 18)
print(output)
