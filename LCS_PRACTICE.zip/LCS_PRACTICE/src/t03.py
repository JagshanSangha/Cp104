"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-12-20"
-------------------------------------------------------
"""
# Imports
total = 0
stop = 5

for i in range(stop):
    total = total + i
    i = i + stop
