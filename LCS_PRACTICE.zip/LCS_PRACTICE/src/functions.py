"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-12-20"
-------------------------------------------------------
"""
# Imports

# Constants
# An airline company is offering customers a special promotion for holiday
# travel. The closer they book to Christmas Eve (December 24th), the
# bigger the discount. The discounts applied are as follows, if the flight
# is booked 6 months or more away from Christmas no discount is applied,
# within 1 month a 10% discount is applied and within a week 15% is
# discounted. There will be a further discount of 5%, on flights that are
# longer than 5 hours, which is applied after the first discount. The
# average price will be $125/hour.


def flight_cost(duration, month_booked, day_booked):
    """
    -------------------------------------------------------
    Calculates discounts on a airline membership and applies 
    them
    Use: final_cost = flight_cost(duration, month_booked, day_booked)
    -------------------------------------------------------
    Parameters:
        duration - the time spent on the plane (float > 0 )
        month_booked - the month they booked from christmas(int >= 0)
        day_booked - the days booked from christmas(int >= 0)
    Returns:
        final_cost - The final cost of the flight (int)
    -------------------------------------------------------
    """
    # assign value to discount
    discount = 1

    # if else statements
    if month_booked >= 11 and 24 < day_booked < 31:
        discount = 10
        if duration > 5:
            discount += 5
    elif month_booked == 12 and 17 < day_booked < 24:
        discount = 15
        if duration > 5:
            discount += 5
    elif month_booked == 12 and 1 <= day_booked < 17:
        discount = 10
        if duration > 5:
            discount += 5

    # final cost calculation
    if discount > 1:
        discount = (125 * duration) * (discount / 100)

    final_cost = ((125 * duration) - discount)

    return final_cost

# Create a function max_diff that determines the largest difference
# between two adjacent numbers in a list. You can assume that all elements
# in the list will be integers and the list is at least length 2.


def max_diff(list):
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """
    difference = 0
    for i in range(len(list) - 1):
        diff = list[i] - list[i + 1]
        if diff >= difference:
            difference = diff
    return difference

# Noah is self-loathing and really hates words that end in the letter h.
# Write a function no_h that removes all the words in a list that end in
# the letter h.
# EX. no_h([“Noah”, “Steven” ,”Mila”]) = [“Steven”, “Mila”]


def no_h(string):
    """
    -------------------------------------------------------
    description
    Use: out = no_h(string)
    -------------------------------------------------------
    Parameters:
        string - string (str)
    Returns:
        result- string without its word with a h (type)
    ------------------------------------------------------
    """
    result = []
    for i in string:
        if i[-1] != "h" and i[-1] != "H":
            result.append(i)
    return result


def over_price(line):
    """
    -------------------------------------------------------
    description
    Use: out = no_h(string)
    -------------------------------------------------------
    Parameters:
        line -  (str)
    Returns:
        name-  (type)
    ------------------------------------------------------
    """
    line_list = line.strip().split(",")
    return float(line_list[1][1:])
