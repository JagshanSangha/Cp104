"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-12-20"
-------------------------------------------------------
"""
# Imports
from functions import max_diff
# Constants
output = max_diff([1, -3, 10, 11, 12])
print(output)
