"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-11-06"
-------------------------------------------------------
"""
# Imports
from functions import multiplication_table

# Constants

# Userinput
start = int(input("Enter the range start value: "))
stop = int(input("Enter the range stop value: "))

# Calculations for table
table = multiplication_table(start, stop)

# Output
table
