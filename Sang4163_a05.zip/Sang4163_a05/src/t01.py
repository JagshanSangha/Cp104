"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-11-06"
-------------------------------------------------------
"""
# Imports
from functions import factorial
# Constants

# Userinput
num = int(input("Enter a number: "))

# Calculating product
product = factorial(num)

# Output
print(f"\n{product}")
