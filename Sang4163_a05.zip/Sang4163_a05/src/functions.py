"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-11-06"
-------------------------------------------------------
"""
# Imports

# Constants


def factorial(num):
    """
    -------------------------------------------------------
    Calculates and returns the factorial of num.
    Use: product = factorial(num)
    -------------------------------------------------------
    Parameters:
        num - number to factorial (int > 0)
    Returns:
        product - num! (int)
    ------------------------------------------------------
    """
    # for loop
    for i in range(num - 1, 0, -1):
        num = num * i

    return num


def calories_burned(per_minute, minutes):
    """
    -------------------------------------------------------
    Calculates and returns the calories burned per minute.
    Use: product = calories_burned(per_minute, minutes)
    -------------------------------------------------------
    Parameters:
        per_minute: calories burned per minute (float > 0)
        minutes - number of minutes (int > 0)
    Returns:
        per_minute - int
        minutes- float
    ------------------------------------------------------
    """
    # for loops with formatting
    for i in range(5, minutes + 1, 5):
        per_mins = per_minute * i
        print(f"{i:>3}:  {per_mins:>3.1f}")
        per_mins = per_minute * i

    return


def open_triangle(num_rows):
    """
    -------------------------------------------------------
    Takes integer parameter and prints triangle of # char
    Use: proudct = open_triangle(num_rows)
    -------------------------------------------------------
    Parameters:
        num_rows - the number of rows (int > 0)
    Returns:
        char - str
    ------------------------------------------------------
    """
    # for loop
    for i in range(num_rows):
        print("#" + (" " * i) + "#")

    return


def multiplication_table(start, stop):
    """
    -------------------------------------------------------
    Prints a multiplication table for values from start to stop.
    Use: multiplication_table(start, stop)
    -------------------------------------------------------
    Parameters:
        start - the range start value (int)
        stop - the range stop value (int)
    Returns:
        None
    ------------------------------------------------------
    """
    # for loop
    print(" ", end='')
    for i in range(start, stop + 1):
        print(f"{i:>3d}", "", end='')

    print("\n ", end="")
    for i in range(start, stop + 1):
        print("----", end="")

    print("")

    for i in range(start, stop + 1):
        print(i, "|", end='')
        for k in range(start, stop + 1):
            print(f"{(i * k):>3d}", "", end='')
        print("")

    return


def range_total(start, increment, count):
    """
    -------------------------------------------------------
    Uses a for loop to sum count values from start by increment.
    Use: total = range_total(start, increment, count)
    -------------------------------------------------------
    Parameters:
        start - the range start value (int)
        increment - the range increment (int)
        count - the number of values in the range (int)
    Returns:
        total - the sum of the range (int)
    ------------------------------------------------------
    """
    # assigning value to total
    total = 0

    # for loop
    for i in range(count):
        total += (start + i * increment)

    return total
