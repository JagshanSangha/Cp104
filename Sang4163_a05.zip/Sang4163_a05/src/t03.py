"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-11-06"
-------------------------------------------------------
"""
# Imports

# Constants

# Imports
from functions import open_triangle
# Constants

# Userinput
num_rows = int(input("Enter the num of rows: "))

# Calculation for charTriangle
charTriangle = open_triangle(num_rows)

# Output
charTriangle
