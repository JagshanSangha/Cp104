"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-11-06"
-------------------------------------------------------
"""
# Imports
from functions import range_total

# Constants

# Userinput
start = int(input("Enter the range start value: "))
incrm = int(input("Enter the range increment: "))
count = int(input("Enter the number of values in the range: "))

# Calcualtions for total
total = range_total(start, incrm, count)

# Output
print(f"\n{total}")
