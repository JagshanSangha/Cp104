"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-11-05"
-------------------------------------------------------
"""
# Imports
from functions import population_growth
# Constants

# call the return then print it
years = population_growth(10000, 1000, 10)
print(years)
