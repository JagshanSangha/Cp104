"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-11-05"
-------------------------------------------------------
"""
# Imports
from functions import get_int
# Constants

# calls return and prints it
value = get_int(0, 100)

# output printed
print(value)
