"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-11-05"
-------------------------------------------------------
"""
# Imports
from random import randint
# Constants


def hi_lo_game(high):
    """
    -------------------------------------------------------
    Plays a random higher-lower guessing game.
    Use: count = hi_lo_game(high)
    -------------------------------------------------------
    Parameters:
        high - maximum random value (int > 1)
    Returns:
        count - the number of guesses the user made (int)
    -------------------------------------------------------
    """
    # use to find random number
    number = randint(1, high)

    # userinput
    GUESS_RANDOM = int(input("Guess: "))
    count = 0

    # while loop
    while (GUESS_RANDOM != number):
        if (GUESS_RANDOM > number):
            print(f'Too high, try again')

        elif (GUESS_RANDOM < number):
            print(f'Too low, try agian')
        GUESS_RANDOM = int(input("Guess: "))
        count = count + 1

    count = count + 1
    print("Congratulations - good guess!")

    # return statement
    return count


def population_growth(target, current, rate):
    """
    -------------------------------------------------------
    Determines the number of years to reach a target population.
    Use: years = population_growth(target, current, rate)
    -------------------------------------------------------
    Parameters:
        target - target population (int > current)
        current - current population (int > 1)
        rate - percent rate of growth (float > 0)
    Returns:
        years - the number of years to reach target population (int)
    -------------------------------------------------------
    """
    # variable year's value
    years = 0

    # while loop
    while target > current:
        years = (years + 1)

        current = (current * (1 + rate / 100))

    # return statement
    return years


def positive_statistics():
    """
    -------------------------------------------------------
    Asks a user to enter a series of positive numbers, then calculates
    and returns the minimum, maximum, total, and average of those numbers.
    Stop processing values when the user enters a negative number.
    The first number entered must be positive.
    Use: minimum, maximum, total, average = positive_statistics()
    -------------------------------------------------------
    Returns:
        minimum - smallest of the entered values (float)
        maximum - largest of the entered values (float)
        total - total of the entered values (float)
        average - average of the entered values (float)
    ------------------------------------------------------
    """
    # Userinput
    User_input = float(input("First value: "))
    x = 1
    total = User_input
    max = User_input
    min = User_input

    # while loop
    while True:
        User_input = float(input("Next value: "))
        if User_input < 0:
            break
        x += 1
        total += User_input
        if User_input > max:
            max = User_input
        elif User_input < min:
            min = User_input

    # calculations
    avg = total / x

    # prints new line
    print()

    # return statement
    return min, max, total, avg


def budget(available):
    """
    -------------------------------------------------------
    Asks a user for a series of expenses in a month. Calculate the
    total expenses and determines whether the user is in "Surplus",
    "Deficit", or "Balanced" status.
    Use: expenses, balance, status = budget(available)
    -------------------------------------------------------
    Parameters:
        available - money currently available (float >= 0)
    Returns:
        expenses - total monthly expenses (float)
        balance - remaining balance (float)
        status - One of (str):
            "Surplus" if user budget is in surplus
            "Deficit" if user budget is in deficit
            "Balanced" if user budget is balanced
    ------------------------------------------------------
    """
    # assigned a value to expenses
    expenses = 0

    # while loop
    while True:
        expense = float(input("Enter another expense (0 to quit): $"))

        if expense != 0:
            expenses += expense
        else:
            break
    balance = available - expenses

    if balance > 0:
        status = "Surplus"
    elif balance < 0:
        status = "Deficit"
    else:
        status = "Balanced"

    # return statement
    return expenses, balance, status


def get_int(low, high):
    """
    -------------------------------------------------------
    Asks a user for an integer value between low and high, and
    continues asking until an acceptable value is input.
    Use: value = get_int(low, high)
    -------------------------------------------------------
    Parameters:
        low - the lowest acceptable integer (inclusive) (int)
        high - the higest acceptable integer (inclusive) (int > low)
    Returns:
        value - a number between low and high (int)
    ------------------------------------------------------
    """
    # while loop with formatting
    while True:
        value = int(
            input(f"Enter a value between {low:d} and high {high:d}: "))
        if value < low:
            print("Value entered is too low")
        elif value >= high:
            print("Value entered is too high")
        else:
            break
    print()

    # return statement
    return value
