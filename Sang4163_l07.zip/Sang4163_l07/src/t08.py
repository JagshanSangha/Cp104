"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-11-05"
-------------------------------------------------------
"""
# Imports
from functions import budget
# Constants

# calls the return then prints it
expenses, balance, status = budget(100)

# output with formatting
print(f"({expenses:.2f}, {balance:.2f}, {status})")
