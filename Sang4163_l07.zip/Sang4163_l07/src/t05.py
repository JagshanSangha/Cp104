"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-11-05"
-------------------------------------------------------
"""
# Imports
from functions import positive_statistics
# Constants

min, max, total, avg = positive_statistics()

# print statement with formatting
print(f"({min:.2f}, {max:.2f}, {total:.2f}, {avg:.2f})")
