"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-12-03"
-------------------------------------------------------
"""
# Imports
from random import randint
from random import uniform
from string import ascii_lowercase
from random import choices
from random import choice
# Constants


def generate_matrix_num(rows, cols, low, high, value_type):
    """
    -------------------------------------------------------
    Generates a 2D list of numbers of the given type, 'float' or 'int'.
    (To generate random float number use random.uniform and to
    generate random integer number use random.randint)
    Use: matrix = generate_matrix_num(rows, cols, low, high, value_type)
    -------------------------------------------------------
    Parameters:
        rows - number of rows in the list (int > 0)
        cols - number of columns (int > 0)
        low - low value of range (float)
        high - high value of range (float > low)
        value_type - type of values in the list, 'float' or 'int' (str)
    Returns:
        matrix - a 2D list of random numbers (2D list of float/int)
    -------------------------------------------------------
    """
    # 2d list
    matrix = []

    # if else statement(with for loops)
    if value_type == 'float':
        for i in range(rows):
            matrix.append([])
            for j in range(cols):
                matrix[i].append(uniform(low, high))
    elif value_type == 'int':
        for i in range(rows):
            matrix.append([])
            for j in range(cols):
                matrix[i].append(randint(low, high))

    # return statement
    return(matrix)


def generate_matrix_char(rows, cols):
    """
    -------------------------------------------------------
    Generates a 2D list of random lower case letter ('a' - 'z') values
    Use: matrix = generate_matrix_char(rows, cols)
    -------------------------------------------------------
    Parameters:
        rows - number of rows in the generated matrix (int > 0)
        cols - number of columns in the generated matrix (int > 0)
    Returns:
        matrix - a 2D list of random characters (2D list of str)
    -------------------------------------------------------
    """
    # 2d list
    matrix = []

    # string
    str = ascii_lowercase

    # for loop
    for i in range(rows):
        matrix.append([])
        for j in range(cols):
            matrix[i].extend(choices(str))

    # return statement
    return(matrix)


def find_position(matrix):
    """
    -------------------------------------------------------
    Determines the first locations [row, column] of smallest and
    largest values in a 2D list.
    Use: s_loc, l_loc = find_position(matrix)
    -------------------------------------------------------
    Parameters:
        matrix - a 2D list of numbers (2D list)
    Returns:
        s_loc - a list of of the row and column location of
            the smallest value in matrix (list of int)
        l_loc - a list of of the row and column location of
            the largest value in matrix (list of int)
    -------------------------------------------------------
    """
    # 2d list
    smallest = matrix[0][0]
    largest = matrix[0][0]
    s_loc = [0, 0]
    l_loc = [0, 0]

    # for loops and while loops
    for x in range(len(matrix)):
        for y in range(len(matrix[x])):
            num = matrix[x][y]
            if(num < smallest):
                smallest = num

                s_loc[0] = x
                s_loc[1] = y
            if(num > largest):
                largest = num
                while len(l_loc) != 0:
                    l_loc.pop()
                l_loc.append(x)
                l_loc.append(y)

    # return statement
    return s_loc, l_loc


def find_word_horizontal(matrix, word):
    """
    -------------------------------------------------------
    Look for word in each row of the given matrix of characters.
    Returns a list of indexes of all rows that are equal to word.
    Returns an empty list if no row is equal to word.
    Use: rows = find_word_horizontal(matrix, word)
    -------------------------------------------------------
    Parameters:
        matrix - the matrix of characters (2D list of str)
        word - the word to search for (str)
    Returns:
        rows - a list of row indexes (list of int)
    ------------------------------------------------------
    """
    # string
    check = ""

    # 2d list
    rows = []

    # for loops
    for x in range(len(matrix)):
        check = ""
        for y in range(len(matrix[x])):
            char = matrix[x][y]
            check += char
        if(check == word):
            rows.append(x)

    # return statement
    return rows


def matrix_transpose(matrix):
    """
    -------------------------------------------------------
    Transpose the contents of matrix. (Swap the rows and columns.)
    Use: transposed = matrix_transpose(matrix):
    -------------------------------------------------------
    Parameters:
        matrix - a 2D list (2D list of *)
    Returns:
        transposed - the transposed matrix (2D list of *)
    ------------------------------------------------------
    """
    # 2d list
    transposed = []

    # assign count a value
    count = 0

    # for loops
    for x in range(len(matrix[0])):
        transposed.append([])
        for y in range(len(matrix)):
            num = matrix[y][x]
            transposed[count].append(num)
        count += 1

    # return statement
    return transposed
