"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-12-03"
-------------------------------------------------------
"""
# Imports
from functions import generate_matrix_num
# Constants

Output = generate_matrix_num(3, 4, -10, 10, "float")
print(Output)
