"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-12-03"
-------------------------------------------------------
"""
# Imports
from functions import find_position
# Constants
Output = find_position([[-6, 5, 7], [3, -6, -2], [9, -8, -7], [0, -7, -6]])
print(Output)
