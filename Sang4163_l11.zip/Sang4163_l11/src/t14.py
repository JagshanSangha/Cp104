"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-12-03"
-------------------------------------------------------
"""
# Imports
from functions import matrix_transpose
# Constants
Output = matrix_transpose([[6, 4, 24], [1, -9, 8]])
print(Output)
