"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-12-03"
-------------------------------------------------------
"""
# Imports
from functions import find_word_horizontal

# Constants
Output = find_word_horizontal(
    [['c', 'a', 't'], ['d', 'o', 'g'], ['b', 'i', 'g']], "dog")
print(Output)
