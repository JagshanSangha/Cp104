"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-11-21"
-------------------------------------------------------
"""
# Imports
from functions import is_sorted, list_positives
# Constants

values = list_positives()
result = is_sorted(values)
print(result)
