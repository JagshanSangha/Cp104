"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-11-21"
-------------------------------------------------------
"""
# Imports

# Constants


def list_factors(num):
    """
    -------------------------------------------------------
    Takes an integer greater than 0 as a parameter (num) and
    returns a list of the factors that make up that number
    excepting the number itself. An integer's factors are the
    whole numbers that the integer can be evenly divided by.
    For example, the factors of 6 are 1, 2, and 3, because 6
    can be evenly divided by all these numbers.
    Use: factors = list_factors(num)
    -------------------------------------------------------
    Parameters:
        num - a positive integer (int > 0)
    Returns:
        factors - positive integer (int > 0)
    ------------------------------------------------------
    """
    # list
    factors = []

    # forloop
    for i in range(1, num):
        if num % i == 0:
            factors.append(i)
    return(factors)


def list_positives():
    """
    -------------------------------------------------------
    Gets a list of positive numbers from a user.
    Negative numbers are ignored. Enter 0 to stop entries.
    Use: numbers = list_positives()
    -------------------------------------------------------
    Returns:
        numbers - A list of positive integers (list of int)
    ------------------------------------------------------
    """
    # list
    list = []

    # userinput
    pos_num = int(input('Enter a positive number: '))

    # while loop
    while pos_num != 0:
        if pos_num > 0:
            list.append(pos_num)
        pos_num = int(input('Enter a positive number: '))
    return(list)


def list_indexes(values, target):
    """
    -------------------------------------------------------
    Finds the indexes of target in values.
    Use: indexes = list_indexes(values, target)
    -------------------------------------------------------
    Parameters:
        values - list of value (list of int)
        target - value to look for in num_list (int)
    Returns:
        locations - list of indexes of target (list of int)
    -------------------------------------------------------
    """
    # list
    locations = []
    n = len(values)

    # for loop
    for i in range(n):
        if target == values[i]:
            locations.append(i)
    return(locations)


def subtract_lists(minuend, subtrahend):
    """
    -------------------------------------------------------
    Updates the list minuend removing from it the values in subtrahend.
    i.e. the values in the first list that appear in the second list
    are not included in the updated list.
    subtrahend is unchanged
    Use: subtract_lists(minuend, subtrahend)
    -------------------------------------------------------
    Parameters:
        minuend - a list of values (list)
        subtrahend - a list of values to remove from minuend (list)
    Returns:
        None
    ------------------------------------------------------
    """
    # for loop
    for i in range(len(subtrahend)):
        j = 0
        while j < (len(minuend)):
            if subtrahend[i] == minuend[j]:
                minuend.pop(j)
                if(j > 0):
                    j -= 1
            else:
                j += 1
    return None


def is_sorted(values):
    """
    -------------------------------------------------------
    Determines whether a list is sorted.
    Use: in_order, index = is_sorted(values)
    -------------------------------------------------------
    Parameters:
        values - a list of values (list)
    Returns:
        in_order - True if values is sorted, False otherwise (bool)
        index - index of first value not in order,
            -1 if in_order is True (int)
    ------------------------------------------------------
    """
    # list
    list = sorted(values)

    # if else statement
    if values == list:
        in_order = True
        index = -1
    else:
        in_order = False
        index = 1
    return(in_order, index)
