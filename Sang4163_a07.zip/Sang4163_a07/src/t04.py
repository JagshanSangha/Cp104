"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-11-21"
-------------------------------------------------------
"""
# Imports
from functions import subtract_lists, list_positives
# Constants

minuend = list_positives()
subtrahend = list_positives()
subtract_lists(minuend, subtrahend)
