"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-11-14"
-------------------------------------------------------
"""
# Imports
from math import fabs
# Constants


def winner():
    """
    -------------------------------------------------------
    Asks the user to enter a series of strings that represent 
    the output of a game with a loop. The user should enter an 
    empty string (just press Enter or return) to signal the end
    of the series. After all strings have been entered, the function
    returns two numbers representing how many times the string "blue"
    appeared in the input and how many times the string "grey"
    appeared in the input.
    Use: count1, count2 = winner()
    -------------------------------------------------------
    Parameters:
        None
    Returns:
        count1, count2
    ------------------------------------------------------
    """
# give count 1 and count 2 values
    count1 = 0
    count2 = 0
# userinput
    output = input('Enter the winning team: ')
    # while loop
    while output == 'blue' or output == 'grey':
        if output == 'blue':
            count1 += 1
            output = input('Enter the winning team: ')
        elif output == 'grey':
            count2 += 1
            output = input('Enter the winning team: ')
    return(count1, count2)


def is_prime(num):
    """
    -------------------------------------------------------
    Determines if num is a prime number.
    Use: prime = is_prime(num)
    -------------------------------------------------------
    Parameters:
        num - a positive integer (int > 1)
    Returns:
        prime - True if num is prime, False otherwise (bool)
    ------------------------------------------------------
    """
# while loop
    while num > 1:
        for i in range(2, num + 1):
            if num % i == 0:
                prime = False
            else:
                prime = True

            return(prime)


def interest_table(principal, rate, payment):
    """
    -------------------------------------------------------
    Prints a table of monthly interest and payments on a loan.
    Use: interest_table(principal, rate, payment)
    -------------------------------------------------------
    Parameters:
        principal - original value of a loan (float > 0)
        rate - yearly interest rate as a % (float >= 0)
        payment - the monthly payment (float > 0)
    Returns:
        None
    ------------------------------------------------------
    """
# print statements with formatting
    print(f'Principal: ${principal:.2f}')
    print(f'Interest rate: {rate:.1f}')
    print(f'Monthly payment: ${payment:.2f}')
    dash_format = '-'
    print(f'{dash_format:->36s}')
    print('Month Interest    Payment    Balance')
    print(f'{dash_format:->36s}')

# calculations
    balance = principal

# give month a value
    month = 0
# while loop
    while balance > 0:
        interest = rate / 100
        month += 1
        interest = (balance * interest) / 12
        balance = (balance - payment) + interest
        if balance < 0:
            payment = payment + balance
            balance = 0.00
        print(f'{month: >5d}  {interest:>7.2f}    {payment:>7.2f}    {balance:>7.2f}')

    return (None)


def digit_count(num):
    """
    -------------------------------------------------------
    Counts the number of digits in an integer.
    Use: count = digit_count(num)
    -------------------------------------------------------
    Parameters:
        num - an integer (int)
    Returns:
        count - the number of digits in num (int)
    ------------------------------------------------------
    """
# calculations using absolute value
    num = fabs(num)

# give count a value
    count = 0

# while loop
    if num == 0:
        count = 1
    else:
        while num >= 1:
            num = num / 10
            count += 1
    return(count)


def sum_factors(num):
    """
    -------------------------------------------------------
    Determines the sum of factors of an integer not including
    the integer itself. An integer's factors are the whole numbers
    that the integer can be evenly divided by.
    Use: total = sum_factors(num)
    -------------------------------------------------------
    Parameters:
        num - a positive integer (int >= 1)
    Returns:
        total - the total of num's factors (int)
    ------------------------------------------------------
    """
# give total a value
    total = 1

# whileloop
    while num >= 1:
        for i in range(2, num):
            if num % i == 0:
                total += i

        return(total)

        break
