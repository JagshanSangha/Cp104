"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-10-01"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use:
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


# output
print('Selected quotes from Mark Twain:')
print()
print(''' "Do the right thing. It will gratify some people and astonish the rest."''')
print(''' "All generalizations are false, including this one."''')
print(''' "It is better to keep your mouth closed and let people think you are a fool''')
print(''' than to open it and remove all doubt."''')
