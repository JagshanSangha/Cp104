"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-10-01"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use:
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


# variables
First = 100
Second = 34
Third = 933

# calculation
Total = First + Second + Third

#output + fstrings
print("Values")
print(f"First:  {First:_>6d}")
print(f"Second: {Second:_>6d}")
print(f"Third:  {Third:_>6d}")
print(f"Total:  {Total:_>6d}")
