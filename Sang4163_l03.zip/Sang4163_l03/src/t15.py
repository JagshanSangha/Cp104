"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-10-01"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


# variables
integer = 654321
decimal = 654.32
phrase = "Hello World"

# output
print(f"{integer:5d}")
print(f"{integer:2f}")
# print(f"{integer:<15s}")
print(f"{decimal:.2f}")
# print(f"{decimal:1d}")
# print(f"{decimal:<15s}")
# print(f"{phrase:.2f}")
# print(f"{phrase:6d}")
print(f"{phrase:<10s}")
