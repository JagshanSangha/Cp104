"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-11-12"
-------------------------------------------------------
"""
# Imports
from functions import get_lotto_numbers
# Constants

# print numbers without formatting
numbers = get_lotto_numbers(6, 1, 49)
print(numbers)
