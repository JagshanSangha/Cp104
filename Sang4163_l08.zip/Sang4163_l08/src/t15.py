"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-11-12"
-------------------------------------------------------
"""
# Imports
from functions import symmetric_difference
# Constants

# list
source1 = [10, 3, 10, 3, 1]
source2 = [8, 2, 7, 3, 6, 10, 32, 99]

# print output
DIFFERENCE = symmetric_difference(source1, source2)
print(DIFFERENCE)
