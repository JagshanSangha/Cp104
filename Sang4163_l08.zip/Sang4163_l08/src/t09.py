"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-11-12"
-------------------------------------------------------
"""
# Imports
from functions import many_search
# Constants

# list
values = [94, 96, -22, -79, -28, 96, -50, 71, 24, -32]

indexes = many_search(values, 96)

# print with formatting
print("Values:", values)
# print new line
print()
# print with formatting
print("Indexes of 96:", indexes)
