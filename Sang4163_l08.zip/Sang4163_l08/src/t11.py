"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-11-12"
-------------------------------------------------------
"""
# Imports
from functions import dot_product
# Constants

# list
source1 = [10, 3, 10, 3, 1]
source2 = [8, 2, 7, 3, 6]

target = dot_product(source1, source2)

# printing output
print("Dot product:", target)
