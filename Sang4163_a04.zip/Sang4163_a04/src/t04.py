"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-10-31"
-------------------------------------------------------
"""
# Imports
from functions import rgb_mix
# Constants

# user_input
rgb1 = str(input("Enter the first RGB colour: "))
rgb2 = str(input("Enter the second RGB colour: "))

# calculation
colour = rgb_mix(rgb1, rgb2)

# output
print("")
print(f"'{colour:s}'")
