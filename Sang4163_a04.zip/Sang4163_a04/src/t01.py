"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-10-31"
-------------------------------------------------------
"""
# Imports
from functions import day_of_week
# Constants

# input/user-input
day_number = int(
    input("Enter a number corresponding to the day of the week: "))

# calculations
day = day_of_week(day_number)

# output with f strings
print("")
print(f"'{day}'")
