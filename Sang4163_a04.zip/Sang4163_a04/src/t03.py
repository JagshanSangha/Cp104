"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-10-31"
-------------------------------------------------------
"""
# Imports
from functions import product_largest
# Constants

# user_input
v1 = float(input("Enter value 1: "))
v2 = float(input("Enter value 2: "))
v3 = float(input("Enter value 3: "))

# calculation
product = product_largest(v1, v2, v3)

# output
print("")
print(f"{product:.0f}")
