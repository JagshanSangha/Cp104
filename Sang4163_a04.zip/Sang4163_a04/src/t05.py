"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-10-31"
-------------------------------------------------------
"""
# Imports
from functions import yee_ha
# Constants

# user_input
number = int(input("Enter a number: "))

# calculation
ans = yee_ha(number)

# output
print("")
print(f"'{ans:s}'")
