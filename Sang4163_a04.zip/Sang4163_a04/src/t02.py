"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-10-31"
-------------------------------------------------------
"""
# Imports
from functions import pollution_level
# Constants

# input/user-input
aqi = int(input("Enter the AQI level: "))

# calculation
level = pollution_level(aqi)

# output with f strings
print("")
print(f"'{level:s}'")
