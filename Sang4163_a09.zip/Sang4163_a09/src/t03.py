"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-12-05"
-------------------------------------------------------
"""
# Imports
from functions import file_stats
# Constants
fh = open('addresses.txt', 'r', encoding='utf-8')
ucount, lcount, dcount, wcount = file_stats(fh)
print(ucount, lcount, dcount, wcount)
fh.close()
