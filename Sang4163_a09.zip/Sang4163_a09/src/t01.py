"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-12-05"
-------------------------------------------------------
"""
# Imports
from functions import file_head
# Constants
fh = open('functions.py', 'r', encoding='utf-8')
file_head(fh, 5)
fh.close()
