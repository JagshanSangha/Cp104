"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-12-05"
-------------------------------------------------------
"""
# Imports
from functions import student_info
# Constants
students = open("students.txt", "r", encoding="utf-8")
l_id, h_id, avg = student_info(students)
print(l_id, h_id, avg)
students.close()
