"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-12-05"
-------------------------------------------------------
"""
# Imports
from functions import file_integers
# Constants
fh = open('numbers.txt', 'r', encoding='utf-8')
result = file_integers(fh)
fh.close()
print(result)
