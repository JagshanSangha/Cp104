"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-12-05"
-------------------------------------------------------
"""
# Imports

# Constants


def file_head(fh, linecount):
    """
    -------------------------------------------------------
    Prints first linecount lines of fh. Line numbering starts at 0.
    If length of file is shorter than linecount, stops printing after
    last line of file.
    Use: file_head(fh, linecount)
    -------------------------------------------------------
    Parameters:
        fh - file to process (file handle - open for reading)
        linecount - number of lines to print (int > 0)
    Returns:
        None
    -------------------------------------------------------
    """
    # assign a value to count
    count = 0

    # read file
    line = fh.readline()

    # while loop
    while line != '' and count < linecount:
        print(line, end='')
        line = fh.readline()
        count += 1

    # return statement
    return None


def file_integers(fh):
    """
    -------------------------------------------------------
    Extracts positive integers from a file into a list of integers.
    Numbers are comma-delimited. Non-numeric tokens are ignored.
    Use: numbers = file_integers(fh)
    -------------------------------------------------------
    Parameters:
        fh - file to process ( (file handle - open for reading)
    Returns:
        numbers - a list of integers from fh (list of int)
    -------------------------------------------------------
    """
    # empty list
    numbers = []

    # nested for loop
    for line in fh:
        data = line.strip().split(',')
        for digits in data:
            if digits.isdigit():
                numbers.append(int(digits))

    # return statement
    return(numbers)


def file_stats(fh):
    """
    -------------------------------------------------------
    Evaluates the contents of a file.
    Use: ucount, lcount, dcount, wcount = file_stats(fh)
    -------------------------------------------------------
    Parameters:
        fh - file to process (file handle - open for reading)
    Returns:
        ucount - The number of uppercase letters in the file (int)
        lcount - The number of lowercase letters in the file (int)
        dcount - The number of digits in the file (int)
        wcount - The number of whitespace characters in the file (int)
    -------------------------------------------------------
    """
    # assign value to ucount, lcount, dcount, wcount
    ucount = 0
    lcount = 0
    dcount = 0
    wcount = 0

    # nested for loop
    for line in fh:
        line = line.strip()
        for i in range(len(line)):
            if line[i].isupper():
                ucount += 1
            if line[i].islower():
                lcount += 1
            if line[i].isdigit():
                dcount += 1
            if line[i].isspace():
                wcount += 1

    # return statement
    return(ucount, lcount, dcount, wcount)


def number_lines(fh_in, fh_out):
    """
    -------------------------------------------------------
    Adds line numbers to a file. Contents of fh_out contain contents
    of fh_in where every line has line numbers added to the beginning
    of the line in the format [number]. Line numbering starts at 0.
    Put a single space after the line number.
    Use: number_lines(fh_in, fh_out)
    -------------------------------------------------------
    Parameters:
        fh_in - file to read (file - open for reading)
        fh_out - file to write (file - open for writing)
    Returns:
        None
    -------------------------------------------------------
    """
    # assign value to count
    count = 0

    # for loop
    for line in fh_in:
        output = f'[{count}] {line}'
        count += 1
        fh_out.write(output)
    # return statement
    return


def student_info(students):
    """
    -------------------------------------------------------
    Get information from a file of students and grades.
    Use: l_id, h_id, avg = student_info(students)
    -------------------------------------------------------
    Parameters:
        students - student information file in the format
            surname,forename,id,mark (file - open for reading)
    Returns:
        l_id - the id of the student with the lowest mark (str)
        h_id - the id of the student with the highest mark (str)
        avg - the average mark (float)
    -------------------------------------------------------
    """
    # lists and assigning values to variables
    line = students.readline().strip().split(",")
    l_id = line[2]
    h_id = line[2]
    grade_Low = int(line[3])
    grade_High = int(line[3])
    avg = 0
    avg = avg + float(line[3])
    count = 1

    # while loop
    while line != [""]:
        avg = avg + float(line[3])
        count = float(count + 1)
        if int(line[3]) < grade_Low:
            l_id = line[2]
        if int(line[3]) > grade_High:
            h_id = line[2]
        line = students.readline().strip().split(",")
    avg = (avg / count)
    return (l_id, h_id, avg)
