"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jagshan
ID:      169024163
Email:   Sang4163l@mylaurier.ca
__updated__ = "2022-10-08"
-------------------------------------------------------
"""
# Imports
from functions import population
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use:
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


new_size = population(100000, 80, 95, 212, 5)
print(new_size)
